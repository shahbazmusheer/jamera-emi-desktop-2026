﻿using DevExpress.XtraEditors;
using DevExpress.DataAccess.Sql;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Jamera.Vouchers
{
    public partial class Cash_Vouchers_History_Master : DevExpress.XtraEditors.XtraUserControl
    {
        public Cash_Vouchers_History_Master()
        {
            InitializeComponent();
            // Initial Load
            Update_Master_History_List();
        }

        // --- Helper to setup Grouping & Summaries ---
        private void ConfigureGrid()
        {
            gridView1.BeginUpdate();

            // Clear existing
            gridView1.GroupSummary.Clear();
            gridView1.Columns["Area Code"].GroupIndex = 0;
            gridView1.Columns["Date"].GroupIndex = 1;

            // Add Summary for Total Received Amount
            GridGroupSummaryItem totalSum = new GridGroupSummaryItem();
            totalSum.FieldName = "Recieved Amt";
            totalSum.SummaryType = DevExpress.Data.SummaryItemType.Sum;
            totalSum.DisplayFormat = "Sum = Rs. {0:#,##0.00}";
            totalSum.ShowInGroupColumnFooter = gridView1.Columns["Recieved Amt"];
            gridView1.GroupSummary.Add(totalSum);

            gridView1.OptionsView.ShowFooter = true;
            gridView1.ExpandAllGroups();
            gridView1.EndUpdate();
        }

        public void Update_Master_History_List(string filter = "")
        {
            sqlDataSource1.Queries.Remove(sqlDataSource1.Queries["Query"]);
            CustomSqlQuery query = new CustomSqlQuery();
            query.Name = "Query";

            // The Master Query joining both tables
            string rawSql = @"
            SELECT * FROM (
                -- 1. Recovery Entries
                SELECT 
                    s.area_code AS [Area Code], cvi.date AS [Date], cvi.ref_no AS [Ref.No],
                    CAST(cvi.emi_voucher_id AS VARCHAR) AS [EMI #], cvi.customer_id AS [Customer Code],
                    acc.name AS [Customer], cvi.due_date AS [Due Date], CAST(cvi.due_amount AS VARCHAR) AS [Due Amount],
                    cvi.item_id AS [Item Code],
                    CASE WHEN cvi.item_id = -1 THEN 'Multiple (' + CAST((SELECT COUNT(*) FROM sale_items si WHERE si.agreement_id = agg.id) AS VARCHAR) + ')' ELSE itm.name END AS [Item],
                    cvi.RECIEVED_AMOUNT AS [Recieved Amt], cvi.BALANCE AS [Balance],
                    'Monthly Installment Paid' AS [Description], 
                    s.id as [StoreID], CONVERT(DATETIME, cvi.date, 103) AS [SortDate]
                FROM cash_voucher_items cvi
                INNER JOIN cash_vouchers cv ON cvi.cash_voucher_id = cv.id
                INNER JOIN stores s ON cv.store_id = s.id
                INNER JOIN accounts acc ON cvi.customer_id = acc.id
                LEFT JOIN items itm ON cvi.item_id = itm.id
                LEFT JOIN aggrements agg ON cvi.ref_no = agg.ref_no

                UNION ALL

                -- 2. Advance Entries
                SELECT 
                    s.area_code AS [Area Code], CONVERT(VARCHAR, agg.date, 105) AS [Date], agg.ref_no AS [Ref.No],
                    CAST(agg.emi_no AS VARCHAR) AS [EMI #], agg.customer_id AS [Customer Code],
                    acc.name AS [Customer], 'At Sale' AS [Due Date], CAST(agg.advance_amount AS VARCHAR) AS [Due Amount],
                    CASE WHEN (SELECT COUNT(*) FROM sale_items si WHERE si.agreement_id = agg.id) > 1 THEN -1 ELSE (SELECT TOP 1 item_id FROM sale_items WHERE agreement_id = agg.id) END AS [Item Code],
                    CASE WHEN (SELECT COUNT(*) FROM sale_items si WHERE si.agreement_id = agg.id) > 1 THEN 'Advance (Multiple)' ELSE 'Advance (' + (SELECT TOP 1 itm_in.name FROM sale_items si_in JOIN items itm_in ON si_in.item_id = itm_in.id WHERE si_in.agreement_id = agg.id) + ')' END AS [Item],
                    agg.advance_amount AS [Recieved Amt], agg.balance AS [Balance],
                    'Advance Paid' AS [Description],
                    s.id as [StoreID], agg.date AS [SortDate]
                FROM aggrements agg
                INNER JOIN stores s ON agg.store_id = s.id
                INNER JOIN accounts acc ON agg.customer_id = acc.id
                WHERE agg.advance_amount > 0
            ) AS MasterHistory " + filter + " ORDER BY SortDate DESC";

            query.Sql = rawSql;
            sqlDataSource1.Queries.Add(query);
            sqlDataSource1.Fill();
            ConfigureGrid();
        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            List<string> filters = new List<string>();

            if(ref_no_inp.Text != "")
            {
                filters.Add($"[Ref.No] = '{ref_no_inp.Text}'");
            }

            if (by_customer_check.Checked && customer_search_cmb.EditValue != null)
                filters.Add($"[Customer Code] = '{customer_search_cmb.EditValue}'");

            if (stores_check.Checked && stores_cmb.EditValue != null)
                filters.Add($"[StoreID] = '{stores_cmb.EditValue}'");

            if (item_chkbx.Checked && items_cmb.EditValue != null)
                filters.Add($"[Item Code] = '{items_cmb.EditValue}'");

            if (by_date_check.Checked)
            {
                string start = from_date_picker.DateTime.ToString("yyyy-MM-dd");
                string end = to_date_picker.DateTime.ToString("yyyy-MM-dd");
                filters.Add($"SortDate >= '{start}' AND SortDate <= '{end}'");
            }

            string finalFilter = filters.Count > 0 ? " WHERE " + string.Join(" AND ", filters) : "";
            Update_Master_History_List(finalFilter);
        }

        // --- Checkbox Changed Logic ---

        private void by_customer_check_CheckedChanged(object sender, EventArgs e)
        {
            customer_search_cmb.Enabled = by_customer_check.Checked;
            if (!by_customer_check.Checked) customer_search_cmb.EditValue = null;
        }

        private void stores_check_CheckedChanged(object sender, EventArgs e)
        {
            stores_cmb.Enabled = stores_check.Checked;
            if (!stores_check.Checked) stores_cmb.EditValue = null;
        }

        private void item_chkbx_CheckedChanged(object sender, EventArgs e)
        {
            items_cmb.Enabled = item_chkbx.Checked;
            if (!item_chkbx.Checked) items_cmb.EditValue = null;
        }

        private void by_date_check_CheckedChanged(object sender, EventArgs e)
        {
            from_date_picker.Enabled = to_date_picker.Enabled = by_date_check.Checked;
            if (!by_date_check.Checked) { from_date_picker.EditValue = null; to_date_picker.EditValue = null; }
        }

        // --- Group Styling (Existing) ---
        private void gridView1_GroupLevelStyle(object sender, DevExpress.XtraGrid.Views.Grid.GroupLevelStyleEventArgs e)
        {
            switch (e.Level)
            {
                case 0: // Area
                    e.LevelAppearance.BackColor = Color.FromArgb(0, 34, 204);
                    e.LevelAppearance.BackColor2 = Color.FromArgb(0, 153, 204);
                    e.LevelAppearance.ForeColor = Color.White;
                    break;
                case 1: // Date
                    e.LevelAppearance.BackColor = Color.FromArgb(221, 0, 221);
                    e.LevelAppearance.BackColor2 = Color.FromArgb(255, 153, 102);
                    e.LevelAppearance.ForeColor = Color.White;
                    break;
            }
        }
    }
}