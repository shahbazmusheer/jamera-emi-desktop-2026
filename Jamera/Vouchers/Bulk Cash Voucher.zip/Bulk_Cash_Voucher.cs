﻿using DevExpress.DataAccess.Sql;
using DevExpress.DataAccess.Sql.DataApi;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Senders;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Views.Grid;
using Jamera.Aggrements;
using Jamera.Properties;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jamera.Vouchers
{
    public partial class Bulk_Cash_Voucher : DevExpress.XtraEditors.XtraUserControl
    {
        Helper_Class helper_Class = new Helper_Class();
        public DataTable cash_voucher_emi_items_table = new DataTable();
        Vouchers_Controller v_controller = new Vouchers_Controller();
        Accounts.Accounts_Controller accounts_controller = new Accounts.Accounts_Controller();
        DataTable expence_items_table = new DataTable();

        DataTable Default_Customer_Reciept_Table = new DataTable();
        Aggrements.Aggrements_Controller aggrements_controller = new Aggrements.Aggrements_Controller();
        Aggrements.Aggrement aggrement;
        int real_last_row = -1;


        Double reciepts_total = 0;
        Double customer_curr_balance = 0;
        public Bulk_Cash_Voucher()
        {
            InitializeComponent();
            sqlDataSource1.Fill();

        }
        private void store_cmb_EditValueChanged(object sender, EventArgs e)
        {
            if (store_cmb.ContainsFocus == true)
            {
                if (store_cmb.Text != "")
                {
                    sqlDataSource1.Queries.Remove(sqlDataSource1.Queries["Query_1"]);
                    CustomSqlQuery query = new CustomSqlQuery();
                    query.Sql = @"select stores.area_code as 'Area Code',accounts.id as 'Code', accounts.name as 'Name',accounts.father_name as 'Father Name', accounts.balance as 'Balance' from (dbo.accounts accounts left join dbo.stores stores on (stores.id = accounts.store_id)) WHERE accounts.account_group_id='1002' and accounts.store_id='" + Convert.ToInt32(store_cmb.EditValue) + "'";
                    query.Name = "Query_1";
                    sqlDataSource1.Queries.Add(query);
                    sqlDataSource1.RebuildResultSchema();
                    sqlDataSource1.Fill();
                    items_cmb.Refresh();
                    ref_no_inp.Focus();
                }
            }
        }
        public void Load_Customer_Dues()
        {
            Default_Customer_Reciept_Table = null;
            Default_Customer_Reciept_Table = aggrements_controller.Get_Customer_Dues_Table_For_Reciepts_Adjustment(ref_no_inp.Text).Copy();
            list.DataSource = Default_Customer_Reciept_Table;
            real_last_row = Default_Customer_Reciept_Table.Rows.Count - 1;
            gridView1.Focus();
        }

        
        private void remaining_balance_inp_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Control && e.KeyCode == Keys.D) || e.KeyCode == Keys.Enter)
            {
                this.Set_Item_To_Cart();
            }
        }
       
        private void customers_cmb_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        public void Set_Item_To_Cart()
        {
            gridView1.Focus();
            gridView1.SelectCell(gridView1.FocusedRowHandle, gridView1.Columns["EMI #"]);
        }
        private void items_cmb_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.D)
            {
                this.Set_Item_To_Cart();
            }
        }


        public void Save()
        {
            try
            {
                // 1. Force the DevExpress Grid to save any active typing into the DataTable
                gridView1.CloseEditor();
                gridView1.UpdateCurrentRow();

                // 2. Initial Validations
                if (store_cmb.EditValue == null || store_cmb.Text == "")
                {
                    XtraMessageBox.Show("Please select a store!", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    store_cmb.ShowPopup();
                    return;
                }

                if (string.IsNullOrEmpty(ref_no_inp.Text) || aggrement == null || aggrement.Aggrement_Id <= 0)
                {
                    XtraMessageBox.Show("Please select a valid Agreement (Ref.No) first!", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ref_no_inp.Focus();
                    return;
                }

                // 3. Check if the user actually entered any amounts
                bool hasPayments = false;
                foreach (DataRow row in Default_Customer_Reciept_Table.Rows)
                {
                    double recAmt = 0;
                    if (row["Recieved Amount"] != DBNull.Value)
                    {
                        double.TryParse(row["Recieved Amount"].ToString(), out recAmt);
                        if (recAmt > 0)
                        {
                            hasPayments = true;
                            // Check if EMI Serial is missing for a paid row
                            if ((row["EMI #"] == DBNull.Value || string.IsNullOrEmpty(row["EMI #"].ToString())) && Settings.Default.check_emi_existence)
                            {
                                XtraMessageBox.Show($"Please provide an EMI Serial Number for the payment of {recAmt}!", "Missing Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }
                }

                if (!hasPayments)
                {
                    XtraMessageBox.Show("No payments detected. Please enter a 'Recieved Amount' for at least one installment.", "Empty Voucher", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                //// 4. Confirm with User
                //if (XtraMessageBox.Show("Are you sure you want to save these bulk receipts and update accounts?", "Confirm Save", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                //{
                //    return;
                //}

                // 5. Execution
                this.Enabled = false; // Prevent double clicking

                // Prepare IDs
                int currentStoreId = Convert.ToInt32(store_cmb.EditValue);
                int currentCustomerId = Convert.ToInt32(customers_cmb.EditValue);

                // Handle Item Code (Use -1 if it's a multiple-item agreement)
                int currentItemId = (items_cmb.Tag?.ToString() == "MULTIPLE") ? -1 : Convert.ToInt32(items_cmb.EditValue);

                // Call the Phase-based Controller Method
                int result = v_controller.Store_Receipts_Table(
                    Default_Customer_Reciept_Table,
                    ref_no_inp.Text,
                    currentStoreId,
                    currentCustomerId,
                    currentItemId
                );

                if (result > 0)
                {
                    // Success
                    Reset_Fields();
                }
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Critical Error during save: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Enabled = true;
            }
        }

        public void Reset_Fields()
        {
            ref_no_inp.Text = string.Join("-", ref_no_inp.Text.Split('-').Take(2)) + "-" + (Convert.ToInt32(ref_no_inp.Text.Split('-')[2]) + 1);
            items_cmb.Text = null;
            customers_cmb.Text = null;
            Default_Customer_Reciept_Table.Clear();
            remaining_balance_inp.Text = "";
            ref_no_inp.Focus();
        }
        private void save_btn_Click(object sender, EventArgs e)
        {
            this.Save();
        }

        private void recieved_amount_total_inp_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch = e.KeyChar;

            if (!(Char.IsDigit(ch) || ch == 13 || ch == 8 || ch == 46))
            {
                e.Handled = true;
                e.Handled = true;
            }

        }

        private void ref_no_inp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) // Enter Key
            {
                loadDetails();
                
            }
        }

        private void loadDetails()
        {

            double itemCount = 0;
            if (string.IsNullOrEmpty(ref_no_inp.Text))
            {
                XtraMessageBox.Show("Please enter Ref.No of agreement!");
                ref_no_inp.Focus();
                return;
            }

            aggrement = aggrements_controller.Get_Aggrement_By_Ref_No(ref_no_inp.Text);

            if (aggrement.Aggrement_Id <= 0)
            {
                XtraMessageBox.Show("Ref.No is not valid!");
                ref_no_inp.Focus();
                return;
            }
            else
            {
                customers_cmb.EditValue = aggrement.Customer_Id;
                // Balance logic anchor
                customer_curr_balance = aggrement.Current_Balance;
                remaining_balance_inp.Text = customer_curr_balance.ToString();

                // Load Items in Items CMB
                sqlDataSource1.Queries.Remove(sqlDataSource1.Queries["Query_2"]);
                CustomSqlQuery query = new CustomSqlQuery();
                query.Sql = @"SELECT s_i.item_id as 'Code',items.name as 'Item',s_i.sale_rate as 'Sale Rate',s_i.sold_qty as 'Qty' from sale_items as s_i left join items on s_i.item_id=items.id left join aggrements as ag on s_i.agreement_id=ag.id  WHERE ag.ref_no='" + ref_no_inp.Text + "'";
                query.Name = "Query_2";
                sqlDataSource1.Queries.Add(query);
                sqlDataSource1.RebuildResultSchema();
                sqlDataSource1.Fill();
                items_cmb.Refresh();

                // Load items for this specific agreement
                DataTable agreementItems = aggrements_controller.Get_Aggrement_Items_Table(aggrement.Aggrement_Id);

                if (agreementItems.Rows.Count > 1)
                {
                    // Calculate real-time total quantity
                    double totalQty = agreementItems.Rows.Count;
                    itemCount = totalQty;
                    //foreach (DataRow row in agreementItems.Rows)
                    //    totalQty += Convert.ToDouble(row["Quantity"]);

                    items_cmb.EditValue = null;
                    items_cmb.Properties.NullText = $"Multiple ({totalQty})"; // Show 'Multiple (3)'
                    items_cmb.Tag = "MULTIPLE";
                }
                else if (agreementItems.Rows.Count == 1)
                {
                    items_cmb.Properties.NullText = "";
                    items_cmb.EditValue = Convert.ToDecimal(agreementItems.Rows[0]["Code"]);
                    items_cmb.Tag = "SINGLE";
                    items_cmb.Focus();
                    itemCount = 1;
                }

                Load_Customer_Dues();

            }
        }

        private void ref_no_inp_EditValueChanged(object sender, EventArgs e)
        {
            
        }

        private void ref_no_inp_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.D)
            {
                this.Set_Item_To_Cart();
            }
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.Reset_Fields();
        }

        private void new_btn_Click(object sender, EventArgs e)
        {
            Cash_Voucher UC = new Cash_Voucher();
            new UC_Opener_Form("New Cash Voucher", UC) { WindowState = FormWindowState.Maximized, Is_New_Cash_Voucher = true, CASH_VOUCHER = UC }.Show(this);
        }

        private void items_cmb_EditValueChanged(object sender, EventArgs e)
        {
            if (items_cmb.Text != "")
            {
                Set_Item_To_Cart();
            }
        }


        private void due_amt_inp_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void field_worker_inp_EditValueChanged(object sender, EventArgs e)
        {

        }

        public void AutoAddEmiRows()
        {
            try
            {
                if (Default_Customer_Reciept_Table.Rows.Count == 0) return;

                // 1. Identify the last row
                DataRow lastRow = Default_Customer_Reciept_Table.Rows[Default_Customer_Reciept_Table.Rows.Count - 1];

                // 2. Safety Check: Only add if the current last row has a balance > 0 
                // AND it actually has a payment (to prevent infinite blank rows)
                double lastBalance = 0;
                double.TryParse(lastRow["Balance"]?.ToString(), out lastBalance);

                double lastReceived = 0;
                double.TryParse(lastRow["Recieved Amount"]?.ToString(), out lastReceived);

                if (lastBalance > 0 && lastReceived > 0)
                {
                    // 3. Calculate values for the New Row
                    int lastSrNo = Convert.ToInt32(lastRow["Sr.No"]);
                    DateTime lastDueDate = DateTime.ParseExact(lastRow["Due Date"].ToString(), "dd-MM-yyyy", null);

                    double standardEmi = aggrement.Rest_EMI;
                    // The new Due Amount is the standard EMI, unless the remaining balance is smaller
                    double nextDueAmount = (lastBalance > standardEmi) ? standardEmi : lastBalance;

                    // 4. Create and Add the Row
                    DataRow newRow = Default_Customer_Reciept_Table.NewRow();
                    newRow["Sr.No"] = lastSrNo + 1;
                    newRow["Code"] = -1; // -1 signals to the Controller that this is a NEW installment
                    newRow["Due Date"] = lastDueDate.AddMonths(1).ToString("dd-MM-yyyy");
                    newRow["Due Amount"] = nextDueAmount.ToString("0.00");
                    newRow["Reciept Date"] = DateTime.Now.ToString("dd-MM-yyyy");

                    // These stay empty for user input
                    newRow["Recieved Amount"] = DBNull.Value;
                    newRow["EMI #"] = DBNull.Value;
                    newRow["Balance"] = DBNull.Value;
                    newRow["Remarks"] = "";

                    Default_Customer_Reciept_Table.Rows.Add(newRow);
                }
            }
            catch (Exception ex)
            {
                // Handle date parsing or conversion errors
            }
        }

        private void gridView1_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (e.Column.FieldName == "EMI #" && gridView1.GetFocusedRowCellValue("EMI #").ToString() != "")
            {
                helper_Class.IfEMINoExists(Convert.ToInt32(gridView1.GetFocusedRowCellValue("EMI #")), Convert.ToInt32(store_cmb.EditValue), Convert.ToDateTime(gridView1.GetFocusedRowCellValue("Reciept Date")), true, Default_Customer_Reciept_Table, "EMI #", gridView1.FocusedRowHandle);
            }

           


            Double collected_amt = 0;
            for (int i = 0; i < Default_Customer_Reciept_Table.Rows.Count; i++)
            {
                if (Default_Customer_Reciept_Table.Rows[i]["Recieved Amount"] != DBNull.Value && Default_Customer_Reciept_Table.Rows[i]["Recieved Amount"].ToString() != "")
                {
                    collected_amt = collected_amt + Convert.ToDouble(Default_Customer_Reciept_Table.Rows[i]["Recieved Amount"]);
                    if (collected_amt > 0 && Default_Customer_Reciept_Table.Rows[i]["Recieved Amount"].ToString() != "0")
                    {
                        Double curr_rem_bal = customer_curr_balance - collected_amt;
                        Default_Customer_Reciept_Table.Rows[i]["Balance"] = curr_rem_bal;
                    }
                    else
                    {
                        Default_Customer_Reciept_Table.Rows[i]["Balance"] = DBNull.Value;
                    }
                }
                else
                {
                    Default_Customer_Reciept_Table.Rows[i]["Balance"] = DBNull.Value;
                }
            }
            if (e.Column.FieldName == "Recieved Amount")
            {
                // Use the DataSource Row Index to ensure we are working with the correct row in the DataTable
                int datasourceIndex = gridView1.GetDataSourceRowIndex(e.RowHandle);
                updateNextRow(datasourceIndex);
            }
        }

        public void updateNextRow(int currentIndex)
        {
            try
            {
                gridView1.BeginUpdate();
                double standardEmi = (aggrement != null) ? aggrement.Rest_EMI : 0;

                if (standardEmi <= 0) return; // Prevent division by zero/infinite loops

                // 1. Determine the starting point for the waterfall
                // We start with the balance left AFTER the row immediately above the current edit
                double runningBalance = (currentIndex == 0)
                    ? customer_curr_balance
                    : Convert.ToDouble(Default_Customer_Reciept_Table.Rows[currentIndex - 1]["Balance"]);

                // 2. CLEANUP: Remove all auto-added extension rows (-1) from the edit point downwards
                // BUT ONLY IF they are empty. This allows us to rebuild the schedule accurately.
                for (int i = Default_Customer_Reciept_Table.Rows.Count - 1; i >= currentIndex; i--)
                {
                    DataRow row = Default_Customer_Reciept_Table.Rows[i];
                    double rec = 0;
                    double.TryParse(row["Recieved Amount"]?.ToString(), out rec);

                    if (row["Code"].ToString() == "-1" && rec <= 0)
                    {
                        Default_Customer_Reciept_Table.Rows.RemoveAt(i);
                    }
                }

                // 3. RECALCULATE: Process existing rows that were kept
                for (int i = currentIndex; i < Default_Customer_Reciept_Table.Rows.Count; i++)
                {
                    DataRow row = Default_Customer_Reciept_Table.Rows[i];

                    // Update Due Amount for extension rows
                    if (row["Code"].ToString() == "-1")
                    {
                        double dAmt = (runningBalance > standardEmi) ? standardEmi : runningBalance;
                        //row["Due Amount"] = dAmt.ToString("0.00");
                    }

                    double received = 0;
                    double.TryParse(row["Recieved Amount"]?.ToString(), out received);

                    runningBalance -= received;
                    //row["Balance"] = runningBalance;
                }

                if(currentIndex >= real_last_row)
                {
                    if (Convert.ToDouble(Default_Customer_Reciept_Table.Rows[real_last_row]["Due Amount"]) < standardEmi)
                    {
                        Default_Customer_Reciept_Table.Rows[real_last_row]["Due Amount"] = standardEmi;
                    }
                }

                // 4. GENERATE: Re-run the Calculate_EMI_Dues logic 
                // Add new rows until the runningBalance reaches zero
                int loopSafety = 0; // Prevent runaway loops
                while ((runningBalance > 0 && loopSafety < 100) && currentIndex >= real_last_row)
                {
                    loopSafety++;
                    DataRow lastRow = Default_Customer_Reciept_Table.Rows[Default_Customer_Reciept_Table.Rows.Count - 1];

                    int lastSrNo = Convert.ToInt32(lastRow["Sr.No"]);
                    DateTime lastDate = DateTime.ParseExact(lastRow["Due Date"].ToString(), "dd-MM-yyyy", null);

                    // This is the core logic from your Calculate_EMI_Dues
                    double nextDueAmount = (runningBalance > standardEmi) ? standardEmi : runningBalance;

                    DataRow newRow = Default_Customer_Reciept_Table.NewRow();
                    newRow["Sr.No"] = lastSrNo + 1;
                    newRow["Code"] = -1;
                    newRow["Due Date"] = lastDate.AddMonths(1).ToString("dd-MM-yyyy");
                    newRow["Due Amount"] = nextDueAmount.ToString("0.00");

                    // Per your requirement: Fields kept empty for user input
                    newRow["Reciept Date"] = lastDate.AddMonths(1).ToString("dd-MM-yyyy");
                    newRow["Recieved Amount"] = DBNull.Value;
                    newRow["EMI #"] = DBNull.Value;
                    newRow["Balance"] = DBNull.Value;
                    newRow["Remarks"] = "";

                    Default_Customer_Reciept_Table.Rows.Add(newRow);

                    // Deduct the scheduled amount from our calculation loop
                    runningBalance -= nextDueAmount;
                }
            }
            catch (Exception ex)
            {
                // Silent catch for UI stability
            }
            finally
            {
                gridView1.EndUpdate();
            }
        }

        public void updateNextRowOld(int currentIndex)
        {
            try
            {
                gridView1.BeginUpdate();
                DataRow currentRow = Default_Customer_Reciept_Table.Rows[currentIndex];

                // 1. Get the starting balance for this specific row
                // If it's the first row, we use the agreement balance. Otherwise, the previous row's balance.
                double incomingBalance = (currentIndex == 0)
                    ? customer_curr_balance
                    : Convert.ToDouble(Default_Customer_Reciept_Table.Rows[currentIndex - 1]["Balance"]);

                double received = 0;
                double.TryParse(currentRow["Recieved Amount"]?.ToString(), out received);

                // 2. Update Current Row Balance
                double currentRemaining = incomingBalance - received;
                currentRow["Balance"] = currentRemaining;

                int nextIndex = currentIndex + 1;

                // 3. Logic: If there is still a balance, manage the Next Row
                if (currentRemaining > 0)
                {
                    double standardEmi = (aggrement != null) ? aggrement.Rest_EMI : 0;
                    double nextDue = (currentRemaining > standardEmi) ? standardEmi : currentRemaining;

                    // Case A: Next row already exists - just update its Due Amount
                    if (nextIndex < Default_Customer_Reciept_Table.Rows.Count)
                    {
                        Default_Customer_Reciept_Table.Rows[nextIndex]["Due Amount"] = nextDue.ToString("0.00");
                    }
                    // Case B: No next row exists - Add a new extension row
                    // Only add if the user has actually entered a payment in the current row
                    else if (received > 0)
                    {
                        int lastSrNo = Convert.ToInt32(currentRow["Sr.No"]);
                        DateTime lastDate = DateTime.ParseExact(currentRow["Due Date"].ToString(), "dd-MM-yyyy", null);

                        DataRow newRow = Default_Customer_Reciept_Table.NewRow();
                        newRow["Sr.No"] = lastSrNo + 1;
                        newRow["Code"] = -1; // Extension marker
                        newRow["Due Date"] = lastDate.AddMonths(1).ToString("dd-MM-yyyy");
                        newRow["Due Amount"] = nextDue.ToString("0.00");
                        newRow["Reciept Date"] = lastDate.AddMonths(1).ToString("dd-MM-yyyy");

                        Default_Customer_Reciept_Table.Rows.Add(newRow);
                    }
                }
                // 4. Logic: If balance is 0, delete any empty auto-added rows below
                else
                {
                    // Prune rows from the bottom up to the nextIndex
                    for (int i = Default_Customer_Reciept_Table.Rows.Count - 1; i >= nextIndex; i--)
                    {
                        DataRow rowToPrune = Default_Customer_Reciept_Table.Rows[i];
                        double rowRec = 0;
                        double.TryParse(rowToPrune["Recieved Amount"]?.ToString(), out rowRec);

                        // Only delete if it's an extension row (-1) and no payment is recorded yet
                        if (rowToPrune["Code"].ToString() == "-1" && rowRec <= 0)
                        {
                            rowToPrune.Delete();
                        }
                    }
                    Default_Customer_Reciept_Table.AcceptChanges();
                }
            }
            catch (Exception ex)
            {
                // Silent fail or log
            }
            finally
            {
                gridView1.EndUpdate();
            }
        }

        private void gridView1_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void list_ProcessGridKey(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.S)
            {
                // 1. Force the active editor to save its current value to the row
                if (gridView1.ActiveEditor != null)
                {
                    gridView1.CloseEditor();
                }

                // 2. Ensure the row is validated and data is pushed to the DataTable
                gridView1.UpdateCurrentRow();

                // 3. Call your Save method
                this.Save();

                // 4. Reset focus to Ref No
                ref_no_inp.Focus();

                // 5. Tell the system we handled this key so it doesn't beep
                e.Handled = true;
            }

        }

        private void view_agreement_btn_Click(object sender, EventArgs e)
        {
            Edit_Aggrement edit_aggrement = new Edit_Aggrement(aggrement.Aggrement_Id);
            UC_Opener_Form form = new UC_Opener_Form("Agreement Details", edit_aggrement);
            edit_aggrement.uc_opener = form;
            form.Show(this);
        }

    }
}
